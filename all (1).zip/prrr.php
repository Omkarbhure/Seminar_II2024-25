<?php
// Set timezone to India
date_default_timezone_set('Asia/Kolkata');

// Send current time and date if requested via AJAX
if (isset($_GET['get_time'])) {
    echo json_encode([
        'time' => date('H:i:s'),
        'date' => date('l, F j, Y')
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Live PHP Digital Clock</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f8ff;
            color: #333;
        }
        .clock-container {
            text-align: center;
            border: 2px solid #ccc;
            padding: 30px;
            border-radius: 12px;
            background-color: #ffffff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .clock {
            font-size: 4.5rem;
            font-weight: bold;
            color: #007BFF;
        }
        .date {
            font-size: 1.5rem;
            margin-top: 15px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="clock-container">
        <div class="clock" id="clock">Loading...</div>
        <div class="date" id="date">Please wait</div>
    </div>

    <script>
        function updateClock() {
            fetch('?get_time=1')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('clock').textContent = data.time;
                    document.getElementById('date').textContent = data.date;
                });
        }

        // Update every second
        setInterval(updateClock, 1000);
        // Run immediately on load
        updateClock();
    </script>
</body>
</html>
